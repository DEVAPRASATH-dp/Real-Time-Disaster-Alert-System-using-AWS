import boto3
import requests
from datetime import datetime
import os

dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

TOPIC_ARN = os.environ['SNS_TOPIC_ARN']
TABLE_NAME = os.environ['TABLE_NAME']  # Set to 'DisasterAlerts'

def lambda_handler(event, context):
    try:
        # Fetch real-time disaster data
        response = requests.get("https://api.reliefweb.int/v1/disasters?appname=disaster-alert&limit=1&sort[]=date:desc")
        data = response.json()

        if not data['data']:
            send_email("🟢 No Disaster Detected", "No real-time disaster detected at this moment.")
            return {'status': 'no_disaster'}

        disaster = data['data'][0]
        disaster_type = disaster['fields'].get('type', ['Unknown'])[0]
        location = disaster['fields'].get('country', [{'name': 'Unknown'}])[0]['name']
        severity = disaster['fields'].get('status', 'Unknown')
        date = disaster['fields'].get('date', {}).get('created', datetime.utcnow().isoformat())
        description = disaster['fields'].get('description', 'No description available')

        disaster_id = f"{disaster_type}-{datetime.utcnow().isoformat()}"

        table = dynamodb.Table(TABLE_NAME)
        table.put_item(Item={
            'disaster_id': disaster_id,
            'type': disaster_type,
            'location': location,
            'severity': severity,
            'description': description,
            'timestamp': date
        })

        message = (
            f"🚨 Disaster Alert 🚨\n\n"
            f"Type: {disaster_type}\n"
            f"Location: {location}\n"
            f"Severity: {severity}\n"
            f"Description: {description}\n"
            f"Time: {date}\n"
        )

        send_email("🚨 Real-Time Disaster Alert", message)
        return {'status': 'disaster_alert_sent'}

    except Exception as e:
        print("Error:", str(e))
        raise

def send_email(subject, message):
    sns.publish(
        TopicArn=TOPIC_ARN,
        Subject=subject,
        Message=message
    )

